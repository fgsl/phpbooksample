<?php

declare(strict_types=1);

namespace Application\Controller;
use Laminas\Mvc\Controller\AbstractActionController;
use Laminas\View\Model\ViewModel;
use Application\Form\Login;
use Application\Model\Usuario;
use Laminas\Authentication\AuthenticationService;
use Laminas\ServiceManager\ServiceManager;

class IndexController extends AbstractActionController
{
    private ?ServiceManager $sm = null;

    public function __construct(ServiceManager $sm)
    {
        $this->sm = $sm;
    }

	public function indexAction()
	{
	    $form = new Login();
	    $form->setAttribute('action', $this->url()->fromRoute('application', ['controller'=>'index', 'action'=>'login']));
	    $messages = '';
	    if ($this->flashMessenger()->getMessages()) {
	        $messages = implode(',', $this->flashMessenger()->getMessages());
	    }
	    return ['form'=>$form, 'messages'=>$messages];
	}
	
	public function loginAction() {
        $request = $this->getRequest();
        $identidade = $request->getPost('identidade');
        $credencial = $request->getPost('credencial');
        $usuario = new Usuario($identidade, $credencial);
        if ($usuario->authenticate($this->sm)) {
            return $this->redirect()->toRoute('application',['controller'=>'index','action'=>'menu']);
        }
        $this->flashMessenger()->addMessage(implode(',',$usuario->messages));
	    return $this->redirect()->toRoute('home');
    }
    
    public function menuAction() {
        $authentication = new AuthenticationService();
        return ['usuario'=>$authentication->getIdentity()];
    }
    
    public function logoutAction() {
        $authentication = new AuthenticationService();
        $authentication->clearIdentity();
        return $this->redirect()->toRoute('home');
    }        	
}
