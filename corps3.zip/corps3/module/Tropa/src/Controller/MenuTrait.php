<?php
namespace Tropa\Controller;
trait MenuTrait
{
    public function indexAction()
    {
        $viewModel = parent::indexAction();
        $viewModel->setVariable('urlHomepage', $this->url()->fromRoute('application/default',
            ['controller'=>'index','action'=>'menu']
        ));
        return $viewModel;
    }
}
