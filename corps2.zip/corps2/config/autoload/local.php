<?php
return [
	'db' => [
		'username' => 'root',
		'password' => '',
	],
];
