<?php
return [
    'db' => [
        'driver' => 'Pdo',
        'dsn' => 'mysql:dbname=corps;hostname=localhost',
    ],
    'service_manager' => [
        'factories' => [
            'LaminasDbAdapter'
            => 'Laminas\Db\Adapter\AdapterServiceFactory',
        ],
    ],
    'navigation' => [
        'default' => [
            [
                'label' => 'Setores Espaciais',
                'route' => 'tropa',
                'controller'=> 'setor',
                'pages' => [
                    [
                        'label' => 'Incluir setor',
                        'route' => 'tropa',
                        'controller'=> 'setor',
                        'action'=> 'edit'
                    ]
                ]
            ],
            [
                'label' => 'Lanternas Verdes',
                'route' => 'tropa',
                'controller' => 'lanterna',
                'pages' => [
                    [
                        'label' => 'Incluir Lanterna',
                        'route' => 'tropa',
                        'controller'=>'lanterna',
                        'action'=> 'edit'
                    ]
                ]
            ],
            [
                'label' => 'Sair',
                'route' => 'application',
                'controller' => 'index',
                'action'=> 'logout'
            ]
        ]
    ],    
];

