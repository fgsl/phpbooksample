<?php
namespace Application\Form;
use Fgsl\Form\AbstractForm;
class Login extends AbstractForm
{
    public function __construct($name = null) {
        parent::__construct('login');
        $this->setAttribute('method', 'post');
        $this->addElement('identidade', self::TEXT, 'Usuário',['autofocus'=>'autofocus']
        )
        ->addElement('credencial', self::PASSWORD, 'Senha')
        ->addElement('submit', self::SUBMIT, 'Entrar');
    }
}
