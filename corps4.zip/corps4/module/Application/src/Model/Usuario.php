<?php
namespace Application\Model;
use Laminas\ServiceManager\ServiceManager;
use Laminas\Authentication\Adapter\DbTable;
use Laminas\Authentication\AuthenticationService;
use Laminas\Mvc\MvcEvent;

class Usuario
{
    private string $identidade;
    private string $credencial;
    public array $messages = array();

    public function __construct(string $identidade, string $credencial) {
        $this->identidade = $identidade;
        $this->credencial = $credencial;
    }

    public function authenticate(ServiceManager $sm) {
    // cria o adaptador para o mecanismo contra o qual se fará a autenticação
        $dbAdapter = $sm->get('LaminasDbAdapter');
        $tableAdapter = new DbTable($dbAdapter);
        $tableAdapter->setIdentityColumn('identidade')
            ->setTableName('usuarios')
            ->setCredentialColumn('credencial')
            ->setIdentity($this->identidade)
            ->setCredential($this->credencial);
        // cria o serviço de autenticação e injeta o adaptador nele
        $authentication = new AuthenticationService();
        $authentication->setAdapter($tableAdapter);
        // autentica
        $result = $authentication->authenticate();
        if ($result->isValid()) {
            // recupera o registro do usuário como um objeto, sem o campo senha
            $usuario = $authentication->getAdapter()->getResultRowObject(null,'senha');
            $authentication->getStorage()->write($usuario);
            return true;
        }
        else {
            $this->messages = $result->getMessages();
            return false;
        }
    }
    
    public static function verifyIdentity(MvcEvent $e) {
        $application = $e->getApplication();
        $request = $application->getRequest();
        $uri = $request->getRequestUri();
        $baseUrl = $request->getBaseUrl();
        // separamos os segmentos do URL e recuperamos o último
        $segment = explode('/',$uri);
        $uri = end($segment);
        $baseUrl = str_replace('/','', $request->getBaseUrl());
        $uri = empty($uri) ? $baseUrl : $uri;
        if ($uri == $baseUrl || $uri == 'login'
    || $uri == 'application')
            return;
        $authentication = new AuthenticationService();
        if (!$authentication->hasIdentity()) {
        // preparamos um redirecionamento para a página de acesso ao sistema
            $router = $application->getServiceManager()->get('Router');
            $url = $router->assemble ( [
                'controller' => 'index',
                'action' => 'index'
                ], [
                    'name' => 'application'
               ]
            );
            $response = $e->getResponse();
            $response->setHeaders($response->getHeaders()->addHeaderLine('Location',$url));
            $response->setStatusCode(302);
            $response->sendHeaders();
            exit ();
        }
    }    
}
