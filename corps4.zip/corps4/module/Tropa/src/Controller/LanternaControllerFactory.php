<?php
namespace Tropa\Controller;

use Laminas\ServiceManager\Factory\FactoryInterface;
use Psr\Container\ContainerInterface;
use Tropa\Model\LanternaTable;
use Tropa\Model\SetorTable;
use Laminas\Db\TableGateway\TableGateway;
use Laminas\Db\ResultSet\ResultSet;
use Tropa\Model\Lanterna;
use Tropa\Model\Setor;

class LanternaControllerFactory implements FactoryInterface
{

    public function __invoke(ContainerInterface $container, $requestedName, ?array $options = null): LanternaController
    {        
        $adapter = $container->get('LaminasDbAdapter');
        $resultSetPrototype = new ResultSet();
        $resultSetPrototype->setArrayObjectPrototype(new Lanterna(
            'codigo',
            'lanterna',
            $adapter));        
        $table = new LanternaTable(new TableGateway('lanterna',$adapter,null,$resultSetPrototype));
        $resultSetPrototype = new ResultSet();
        $resultSetPrototype->setArrayObjectPrototype(new Setor(
            'codigo',
            'setor',
            $adapter));        
        $parentTable = new SetorTable(new TableGateway('setor',$adapter,null,$resultSetPrototype));
        return new LanternaController($table, $parentTable);
    }
}
