<?php
namespace Tropa\Controller;

use Laminas\ServiceManager\Factory\FactoryInterface;
use Psr\Container\ContainerInterface;
use Tropa\Model\SetorTable;
use Laminas\Db\TableGateway\TableGateway;
use Laminas\Db\ResultSet\ResultSet;
use Tropa\Model\Setor;

class SetorControllerFactory implements FactoryInterface
{

    public function __invoke(ContainerInterface $container, $requestedName, ?array $options = null): SetorController
    {        
        $adapter = $container->get('LaminasDbAdapter');
        $resultSetPrototype = new ResultSet();
        $resultSetPrototype->setArrayObjectPrototype(new Setor(
            'codigo',
            'setor',
            $adapter));
        $table = new SetorTable(new TableGateway('setor',$adapter,null,$resultSetPrototype));
        return new SetorController($table);
    }
}
