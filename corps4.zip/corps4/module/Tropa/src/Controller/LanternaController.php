<?php
namespace Tropa\Controller;

use Fgsl\Mvc\Controller\AbstractCrudController;
use Laminas\Form\Form;
use Tropa\Form\Lanterna as LanternaForm;

class LanternaController extends AbstractCrudController
{
    use MenuTrait;
    
    protected int $itemCountPerPage = 10;    

    protected string $modelClass = 'Tropa\Model\Lanterna';

    protected string $route = 'tropa';

    protected string $tableClass = 'Tropa\Model\LanternaTable';
    
    public function getForm(bool $full = FALSE): Form
    {
        return new LanternaForm(null,['table'=>$this->parentTable]);
    }
    
    public function getEditTitle($key): string
    {
        return (is_null($key) ? 'Incluir' : 'Alterar') . ' Lanterna';
    }

}                
