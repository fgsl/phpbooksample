<?php
namespace Tropa\Controller;
trait MenuTrait
{
    public function indexAction()
    {
        $viewModel = parent::indexAction();
        $viewModel->setVariable('urlHomepage', $this->url()->fromRoute('application',
            ['controller'=>'index','action'=>'menu']
        ));
        return $viewModel;
    }
}
