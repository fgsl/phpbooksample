<?php
declare(strict_types=1);

namespace Tropa\Controller;
use Fgsl\Mvc\Controller\AbstractCrudController;
use Laminas\Form\Form;
use Tropa\Form\Setor as SetorForm;

class SetorController extends AbstractCrudController
{
    use MenuTrait;
    
    protected int $itemCountPerPage = 10;    

    protected string $modelClass = 'Tropa\Model\Setor';

    protected string $route = 'tropa';

    protected string $tableClass = 'Tropa\Model\SetorTable';
    
    public function getForm(bool $full = FALSE): Form
    {
        return new SetorForm();
    }
    
    public function getEditTitle($key): string
    {
        return (is_null($key) ? 'Incluir' : 'Alterar') . ' Setor';
    }
    
}
