<?php
namespace Tropa\Model;

use Fgsl\InputFilter\InputFilter;
use Laminas\Filter\ToInt;
use Laminas\Filter\StripTags;
use Laminas\Filter\StringTrim;
use Laminas\Validator\Digits;
use Laminas\Validator\StringLength;
use Laminas\InputFilter\InputFilterInterface;

class Lanterna extends AbstractCustomModel
{
    public function populate($rowData, $rowExistsInDatabase = false)
    {
        $nomeSetor = (isset($rowData['setor'])) ? $rowData['setor'] : null;
        $rowData['setor'] = new Setor('codigo','setor',$this->sql->getAdapter());
        $rowData['setor']->codigo = (isset($rowData['codigo_setor'])) ? $rowData['codigo_setor'] : null;
        $rowData['setor']->nome = $nomeSetor;
        parent::populate($rowData, $rowExistsInDatabase);
    }
    
    public function getInputFilter(): InputFilterInterface
    {
        if (! $this->inputFilter) {
            $inputFilter = new InputFilter();
            $inputFilter->addFilter('nome', new StripTags())
            ->addFilter('nome', new StringTrim())
            ->addValidator('nome', new StringLength([
                'encoding' => 'UTF-8',
                'min' => 2,
                'max' => 30
            ]))
            ->addFilter('codigo_setor', new ToInt())
            ->addValidator('codigo_setor', new Digits())
            ->addChains();
            $this->inputFilter = $inputFilter;
        }
        return $this->inputFilter;
    }
    
    public function getArrayCopy()
    {
        $data = $this->data;
        $data['codigo_setor'] = $data['setor']->codigo;
        unset($data['setor']);
        return $data;
    }
}
