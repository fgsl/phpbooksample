<?php
namespace Tropa\Model;

use Fgsl\Db\TableGateway\AbstractTableGateway;;
use Fgsl\Model\AbstractActiveRecord;

class LanternaTable extends AbstractTableGateway
{
    protected string $keyName = 'codigo';
    
    protected string $modelName = 'Tropa\Model\Lanterna';
    
    public function save(AbstractActiveRecord $model, $excludePrimaryKey = false)
    {
        parent::save($model,true);
    }
}
