<?php
namespace Tropa\Model;
use Fgsl\InputFilter\InputFilter;
use Laminas\Filter\ToInt;
use Laminas\Filter\StripTags;
use Laminas\Filter\StringTrim;
use Laminas\Validator\Between;
use Laminas\Validator\StringLength;
use Laminas\InputFilter\InputFilterInterface;

class Setor extends AbstractCustomModel
{
    public function getInputFilter(): InputFilterInterface
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $inputFilter->addFilter('codigo', new ToInt())
            ->addValidator('codigo', new Between([
                'min' => 0,
                'max' => 3600
            ]))
            ->addFilter('nome', new StripTags())
            ->addFilter('nome', new StringTrim())
            ->addValidator('nome', new StringLength([
                'encoding' => 'UTF-8',
                'min' => 2,
                'max' => 30
            ]));
            $this->inputFilter = $inputFilter;
        }
        return $this->inputFilter;
    }
}

