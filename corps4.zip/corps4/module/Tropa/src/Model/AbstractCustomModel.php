<?php
namespace Tropa\Model;
use Fgsl\Model\AbstractActiveRecord;
use Laminas\InputFilter\InputFilterInterface;

abstract class AbstractCustomModel extends AbstractActiveRecord
{
}

