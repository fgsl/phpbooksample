<?php
namespace Tropa\Model;

use Fgsl\Db\TableGateway\AbstractTableGateway;

class SetorTable extends AbstractTableGateway
{  
    protected string $keyName = 'codigo';
    
    protected string $modelName = 'Tropa\Model\Setor';
}    
